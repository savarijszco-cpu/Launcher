package app.olauncher.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewTreeObserver
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import app.olauncher.databinding.ViewHomeAppBinding
import app.olauncher.helper.isEinkDisplay
import app.olauncher.helper.isSystemAnimationsDisabled
import kotlin.math.roundToInt

/**
 * Home-screen app row: a name plus its launcher icon.
 *
 * The icon appears at the same size as the text, mostly under the label and to
 * the left of its resting place. It holds, then shrinks to half and slides up
 * and to the right into the slot just before the name.
 *
 * The row only measures the final half-size slot, so the large icon can draw
 * outside the row (parent must not clip) without pushing the other apps down.
 */
class HomeAppView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    private val label: android.widget.TextView
    private val icon: android.widget.ImageView
    private var iconPx: Int = 0
    private var iconSlotPx: Int = 0
    private var gapPx: Float = 0f
    private var animator: Animator? = null
    private var layoutListener: ViewTreeObserver.OnGlobalLayoutListener? = null

    init {
        clipChildren = false
        clipToPadding = false
        val binding = ViewHomeAppBinding.inflate(LayoutInflater.from(context), this, true)
        label = binding.homeAppLabel
        icon = binding.homeAppIcon
    }

    fun setContentGravity(horizontalGravity: Int) {
        label.gravity = horizontalGravity
    }

    fun showApp(name: String, iconDrawable: Drawable?, animate: Boolean, startDelay: Long = 0L) {
        animator?.cancel()
        translationZ = 0f
        clearLayoutListener()
        label.text = name
        contentDescription = name.ifBlank { null }
        if (name.isBlank() || iconDrawable == null) {
            icon.setImageDrawable(null)
            icon.visibility = GONE
            iconPx = 0
            iconSlotPx = 0
            requestLayout()
            return
        }

        val full = label.textSize.coerceAtLeast(1f)
        gapPx = 8f * resources.displayMetrics.density
        iconPx = full.roundToInt().coerceAtLeast(1)
        iconSlotPx = (full / 2f + gapPx).roundToInt()
        icon.setImageDrawable(iconDrawable)
        icon.visibility = INVISIBLE
        requestLayout()
        afterNextLayout {
            runIntro(animate && motionAllowed(), startDelay)
        }
    }

    private fun motionAllowed(): Boolean =
        !context.isEinkDisplay() && !context.isSystemAnimationsDisabled()

    private fun runIntro(animate: Boolean, startDelay: Long) {
        if (iconPx <= 0 || label.width == 0) {
            icon.visibility = GONE
            return
        }
        val full = iconPx.toFloat()
        val half = full / 2f
        val rtl = layoutDirection == LAYOUT_DIRECTION_RTL
        val textBottom = label.top + label.baseline + label.paint.fontMetrics.descent
        val finalLeft = if (!rtl) label.left - gapPx - half else label.right + gapPx
        val finalTop = textBottom - half
        val finalTx = finalLeft - icon.left
        val finalTy = finalTop - icon.top

        icon.pivotX = 0f
        icon.pivotY = 0f

        if (!animate) {
            icon.scaleX = 0.5f
            icon.scaleY = 0.5f
            icon.translationX = finalTx
            icon.translationY = finalTy
            icon.alpha = 1f
            icon.visibility = VISIBLE
            translationZ = 0f
            return
        }

        // Under the text and left of the final slot, so the icon travels up and to the right.
        val startLeft = finalLeft - full * 0.65f
        val startTop = label.bottom - full * 0.2f
        icon.scaleX = 1f
        icon.scaleY = 1f
        icon.translationX = startLeft - icon.left
        icon.translationY = startTop - icon.top
        icon.alpha = 0f
        icon.visibility = VISIBLE
        translationZ = 8f

        val fadeIn = ObjectAnimator.ofFloat(icon, View.ALPHA, 0f, 1f).apply { duration = 160 }
        val hold = ObjectAnimator.ofFloat(icon, View.ALPHA, 1f, 1f).apply { duration = 380 }
        val move = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(icon, View.TRANSLATION_X, icon.translationX, finalTx),
                ObjectAnimator.ofFloat(icon, View.TRANSLATION_Y, icon.translationY, finalTy),
                ObjectAnimator.ofFloat(icon, View.SCALE_X, 1f, 0.5f),
                ObjectAnimator.ofFloat(icon, View.SCALE_Y, 1f, 0.5f),
            )
            duration = 520
            interpolator = DecelerateInterpolator()
        }
        animator = AnimatorSet().apply {
            this.startDelay = startDelay
            playSequentially(fadeIn, hold, move)
            addListener(object : AnimatorListenerAdapter() {
                private fun drop() {
                    translationZ = 0f
                }

                override fun onAnimationEnd(animation: Animator) = drop()
                override fun onAnimationCancel(animation: Animator) = drop()
            })
            start()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val unspecified = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED)
        label.measure(unspecified, unspecified)
        if (iconPx > 0 && icon.visibility != GONE) {
            val exact = MeasureSpec.makeMeasureSpec(iconPx, MeasureSpec.EXACTLY)
            icon.measure(exact, exact)
        }
        val slot = if (iconPx > 0 && icon.visibility != GONE) iconSlotPx else 0
        val width = paddingLeft + paddingRight + slot + label.measuredWidth
        val height = paddingTop + paddingBottom + label.measuredHeight
        setMeasuredDimension(resolveSize(width, widthMeasureSpec), resolveSize(height, heightMeasureSpec))
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        val rtl = layoutDirection == LAYOUT_DIRECTION_RTL
        val slot = if (iconPx > 0 && icon.visibility != GONE) iconSlotPx else 0
        val labelWidth = label.measuredWidth
        val labelHeight = label.measuredHeight
        val contentHeight = bottom - top - paddingTop - paddingBottom
        val labelTop = paddingTop + (contentHeight - labelHeight) / 2
        val labelLeft = if (!rtl) paddingLeft + slot else measuredWidth - paddingRight - slot - labelWidth
        label.layout(labelLeft, labelTop, labelLeft + labelWidth, labelTop + labelHeight)

        if (iconPx > 0 && icon.visibility != GONE) {
            val iconLeft = if (!rtl) paddingLeft else measuredWidth - paddingRight - iconPx
            val iconTop = paddingTop
            icon.layout(iconLeft, iconTop, iconLeft + iconPx, iconTop + iconPx)
        }
    }

    private fun afterNextLayout(block: () -> Unit) {
        clearLayoutListener()
        val listener = object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                clearLayoutListener()
                if (isAttachedToWindow) block()
            }
        }
        layoutListener = listener
        viewTreeObserver.addOnGlobalLayoutListener(listener)
    }

    private fun clearLayoutListener() {
        val listener = layoutListener ?: return
        layoutListener = null
        if (viewTreeObserver.isAlive) viewTreeObserver.removeOnGlobalLayoutListener(listener)
    }

    override fun setVisibility(visibility: Int) {
        if (visibility != VISIBLE) animator?.cancel()
        super.setVisibility(visibility)
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        clearLayoutListener()
        super.onDetachedFromWindow()
    }
}
